//
//  PostTableViewCell.swift
//  TestInstaGram

import UIKit

class PostTableViewCell: UITableViewCell {
    @IBOutlet weak var userImageView: UIImageView?
    @IBOutlet weak var imageView1: UIImageView?
    @IBOutlet weak var userNicknameLabel: UILabel?
    @IBOutlet weak var imageScrollView: UIScrollView?
    @IBOutlet weak var imageStackView: UIStackView?
    @IBOutlet weak var likeButton: UIButton?
    @IBOutlet weak var detailLabel: UILabel?
    
    @IBOutlet weak var constraintStackViewWidth: NSLayoutConstraint?

    func setData(post: Post){
        guard let imageScrollView = imageScrollView else {return}
        guard let imageStackView = imageStackView else {return}
        guard let constraintStackViewWidth = constraintStackViewWidth else {return}
        if(post.imageUrls.count > imageStackView.subviews.count){
            for _ in 0..<(post.imageUrls.count - imageStackView.subviews.count) {
                imageStackView.addArrangedSubview(UIImageView())
            }
        }else if(post.imageUrls.count < imageStackView.subviews.count){
            let removeCount = (imageStackView.subviews.count - post.imageUrls.count)
            for _ in 0..<removeCount {
                imageStackView.subviews[removeCount].removeFromSuperview()
            }
        }
        for (index, imageUrl) in post.imageUrls.enumerated() {
            (imageStackView.subviews[0] as! UIImageView).sd_setImage(with: imageUrl)
        }
        constraintStackViewWidth.constant = CGFloat(post.imageUrls.count - 1) * imageScrollView.bounds.width
        imageStackView.layoutIfNeeded()
    }

}
