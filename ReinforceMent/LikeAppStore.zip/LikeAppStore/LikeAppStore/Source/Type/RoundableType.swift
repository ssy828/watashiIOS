

enum RoundableType {
  case todayCardType
  case gameCardType
}
